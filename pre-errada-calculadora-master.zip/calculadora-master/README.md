# Calculadora
Exercici per a la practica1 UF2
